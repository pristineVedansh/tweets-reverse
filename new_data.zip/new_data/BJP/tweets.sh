#!/bin/bash


for name in AmitShah narendramodi ianuragthakur KapilMishra_IND DilipGhoshBJP blsanthosh amitmalviya
do
    echo "Started mining user: $name"    
    twint -u $name --since 2019-10-01 --until 2020-06-30 --csv -o $name.csv    
done

exit 0