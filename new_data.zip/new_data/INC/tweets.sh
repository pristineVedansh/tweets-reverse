#!/bin/bash


for name in RahulGandhi priyankagandhi MukeshSharmaMLA rssurjewala adhirrcinc PChidambaram_IN
do
    echo "Started mining user: $name"    
    twint -u $name --since 2019-10-01 --until 2020-06-30 --csv -o $name.csv    
done

exit 0